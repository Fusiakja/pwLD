.onLoad <- function(lib,pkg)
{
  #library.dynam("pwLD", pkg, lib)
  #cat("pwLD 1.1 loaded\n")
}
